from flask import render_template, request, redirect
from . import movie
from ..models import Nodes_xyzs,Edges_xyzs

@movie.route('/')
def index():
    return render_template('index.html')

@movie.route('/xyzs')
def movie():
    nodes = list(Nodes_xyzs.query.all())
    nodes_num = Nodes_xyzs.query.count()
    edges = list(Edges_xyzs.query.all())
    edges_num = Edges_xyzs.query.count()
    return render_template('movie.html', nodes_num =nodes_num ,edges = edges, edges_num =edges_num,
                           nodes = nodes)



